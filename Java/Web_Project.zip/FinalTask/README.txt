WebProject --- Java 11

Database name --> webproject

table1 --> name infcustomer
column1 --> name customer_name : type varchar(45)
column2 --> name email : type varchar(45) : primary key
column3 --> name customer_password : type varchar(45)
column4 --> name age : type varchar(45)
column5 --> name job_role : type varchar(45)

table2 --> name infcourse
column1 --> name course_name : type varchar(25) : primary key
column2 --> name price : type int(11) : NOT NULL
column3 --> name people_taken : type int(11) : NULL
column4 --> name duration : type int(11) : NULL

table3 --> name contentcourse
column1 --> name email : type varchar(45) : primary key
column2 --> name Python : type enum('T','F') : NULL : Default('F')
column3 --> name Java : type enum('T','F') : NULL : Default('F')
column4 --> name PHP : type enum('T','F') : NULL : Default('F')
column5 --> name Android : type enum('T','F') : NULL : Default('F')
column6 --> name cPlus : type enum('T','F') : NULL : Default('F')
column7 --> name Kotlin : type enum('T','F') : NULL : Default('F')
column8 --> name cSharp : type enum('T','F') : NULL : Default('F')
column9 --> name Javascript : type enum('T','F') : NULL : Default('F')

No localization unfortunately
