package kz.epam.webproject.entity;

import java.io.Serializable;

public abstract class Entity implements Serializable, Cloneable {
}
