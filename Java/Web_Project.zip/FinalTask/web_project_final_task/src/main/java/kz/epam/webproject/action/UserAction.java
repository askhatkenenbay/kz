package kz.epam.webproject.action;

import java.io.UnsupportedEncodingException;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;

public class UserAction {
    private static Logger logger = Logger.getLogger(UserAction.class);

    private static final String UNDER_18 = "under_18";
    private static final String OVER_18 = "over_18";
    private static final String STRING_T = "T";
    private static final String STRING_F = "F";
    private static final String STRING_BLANK = "";
    private static final String ALGORITHM = "SHA-1";
    private static final String CHAR_SET_NAME = "utf-8";

    /**
     * This method is used to change parameter age of user to other variation
     * @param age input string from JSP register, can be only 'under_18' or 'over_18'
     * @return  if input is 'under_18', String 'F' will be returned,
     * else if input is 'over_18', String 'T' will be returned,
     * else if input is not any of two possibilities, input itself will be returned
     */
    public static String changeAge(String age) {
        if (UNDER_18.equals(age)) {
            return STRING_F;
        } else if (OVER_18.equals(age)) {
            return STRING_T;
        } else {
            return age;
        }
    }

    /**
     * This method is used to encrypt user information before sending it to be stored in database
     *
     * @param plaintext String of plaintext which will be encrypted
     * @return if everything fine, return String of ciphertext,
     * else if plaintext is null of blank, will return blank String
     * in case of exception, will return blank String
     */
    public static String encrypInput(String plaintext) {
        if (plaintext == null || plaintext.isBlank()) {
            return STRING_BLANK;
        }
        byte[] bytes;
        try {
            MessageDigest messageDigest = MessageDigest.getInstance(ALGORITHM);
            messageDigest.update(plaintext.getBytes(CHAR_SET_NAME));
            bytes = messageDigest.digest();
            BigInteger bigInteger = new BigInteger(1, bytes);
            return bigInteger.toString(16);
        } catch (NoSuchAlgorithmException e) {
            logger.log(Level.ERROR,"Plaintext: " + plaintext + " was NOT encrypted");
        } catch (UnsupportedEncodingException e) {
            logger.log(Level.ERROR,"Plaintext: " + plaintext + " was NOT encrypted");
        }
        return STRING_BLANK;
    }

    public static boolean regexCheck(String theRegex, String str2Check) {
        return Pattern.matches(theRegex, str2Check);
    }
    public static boolean regexCheckEmail(String theRegex, String str2Check){
        Pattern pattern = Pattern.compile(theRegex, Pattern.CASE_INSENSITIVE);
        Matcher matcher = pattern .matcher(str2Check);
        return matcher.find();
    }
    /**
     * Private constructor to make sure that no one creates instance of this class
     */
    private UserAction() {
        throw new IllegalStateException("Utility Class");
    }
}
