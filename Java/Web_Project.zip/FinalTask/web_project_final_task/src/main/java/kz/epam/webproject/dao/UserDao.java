package kz.epam.webproject.dao;

import kz.epam.webproject.entity.Customer;

import java.util.Set;

public interface UserDao extends BaseDao<String, Customer> {
    boolean addUser(String name, String email, String password, String age, String job) throws DaoException;

    boolean singIn(String login, String password) throws DaoException;

    int getTotalPrice(String login) throws DaoException;

    int getPeopleTaken(String courseName) throws DaoException;

    String addCourse(String login, Set<String> set) throws DaoException;
}
