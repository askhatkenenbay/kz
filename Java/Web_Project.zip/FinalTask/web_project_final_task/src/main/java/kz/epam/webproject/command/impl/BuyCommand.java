package kz.epam.webproject.command.impl;

import kz.epam.webproject.command.Command;
import kz.epam.webproject.command.service.UserService;

import javax.servlet.http.HttpServletRequest;
import java.util.HashSet;
import java.util.Set;

import static kz.epam.webproject.command.impl.PageAdress.PAGE_TRANSACTION;
import static kz.epam.webproject.command.impl.PageAdress.PARAM_LOGIN;

public class BuyCommand implements Command {
    private static final String[] POSSIBLE_COURSES = {"Python", "Java", "PHP", "Android", "cPlus", "Kotlin", "cSharp", "Javascript",};
    private static final String STRING_T = "T";

    /**
     * This method is used to collect information from JSP page 'cart' and save all courses user bought.
     * First it saves login (email) of current user in String login, then it saved all courses in cart in Set<String>
     * It uses this to parameters to call UserService class's addCourseToUser method, from which method gets message to be
     * saved as attribute 'message';
     * In the end it moves user to JSP page "transaction' where message will be displayed
     *
     * @param request request from JSP page
     * @return String page
     */
    @Override
    public String execute(HttpServletRequest request) {
        String login = (String) request.getSession().getAttribute(PARAM_LOGIN);
        Set<String> set = new HashSet();
        for (int i = 0; i < POSSIBLE_COURSES.length; i++) {
            if (STRING_T.equals(request.getParameter(POSSIBLE_COURSES[i]))) {
                set.add(POSSIBLE_COURSES[i]);
            }
        }
        request.setAttribute("message", UserService.addCourseToUser(login, set));
        return PAGE_TRANSACTION;
    }
}
