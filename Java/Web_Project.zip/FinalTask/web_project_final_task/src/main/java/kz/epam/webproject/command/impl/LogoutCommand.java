package kz.epam.webproject.command.impl;

import kz.epam.webproject.command.Command;

import javax.servlet.http.HttpServletRequest;

import static kz.epam.webproject.command.impl.PageAdress.PAGE_LOGIN;

public class LogoutCommand implements Command {
    /**
     * This methiod is used to invalidate seesion of current user
     *
     * @param request request from JSP
     * @return login page
     */
    public String execute(HttpServletRequest request) {
        request.getSession().invalidate();
        return PAGE_LOGIN;
    }
}
