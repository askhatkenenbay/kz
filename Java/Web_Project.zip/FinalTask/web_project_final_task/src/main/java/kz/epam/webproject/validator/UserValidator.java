package kz.epam.webproject.validator;

import kz.epam.webproject.action.UserAction;

public class UserValidator {
    private static final String UNDER_18 = "under_18";
    private static final String OVER_18 = "over_18";
    private static final int MIN_NAME_LENGTH = 3;
    private static final int MAX_NAME_LENGTH = 20;
    private static final int MIN_EMAIL_LENGTH = 10;
    private static final int MAX_EMAIL_LENGTH = 40;
    private static final int MIN_PASSWORD_LENGTH = 8;
    private static final int MAX_PASSWORD_LENGTH = 25;
    private static final String REGEX_NAME = "[A-Z][a-z]{2,19}";
    private static final String REGEX_EMAIL = "^[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,6}$";
    //Be between 8 and 40 characters long, Contain at least one digit,one lower case character,one upper case character,one special character from [ @ # $ % ! . ]
    private static final String REGEX_PASSWORD = "^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\\S+$).{8,}$";
    /**
     * This method is used to validate input parameters of new user
     *
     * @param name     name of user
     * @param email    email of user
     * @param password password of user
     * @param age      age of user
     * @param jobRole  job role of user, can be empty, null
     * @return true if all parameters are valid, else returns false;
     */
    public static boolean validateUser(String name, String email, String password, String age, String jobRole) {
        if (name == null || name.length() < MIN_NAME_LENGTH || name.length() > MAX_NAME_LENGTH || !UserAction.regexCheck(REGEX_NAME,name)) {
            return false;
        }
        if (email == null || email.length() < MIN_EMAIL_LENGTH || email.length() > MAX_EMAIL_LENGTH || !UserAction.regexCheckEmail(REGEX_EMAIL,email)) {
            return false;
        }
        if (password == null || password.length() < MIN_PASSWORD_LENGTH || password.length() > MAX_PASSWORD_LENGTH || !UserAction.regexCheck(REGEX_PASSWORD,password)) {
            return false;
        }
        if (!(UNDER_18.equals(age) || OVER_18.equals(age))) {
            return false;
        }
        return true;
    }

    /**
     * This method is used to check input of already registered user
     *
     * @param email    email of user
     * @param password password of user
     * @return returns true if both of inputs are valid , else returns false
     */
    public static boolean validateUser(String email, String password) {
        if (email == null || email.length() < MIN_EMAIL_LENGTH || email.length() > MAX_EMAIL_LENGTH) {
            return false;
        }
        if (password == null || password.length() < MIN_PASSWORD_LENGTH || password.length() > MAX_PASSWORD_LENGTH) {
            return false;
        }
        return true;
    }

    /**
     * Private constructor to make sure that no one creates instance of this class
     */
    private UserValidator() {
        throw new IllegalStateException("Utility Class");
    }
}
