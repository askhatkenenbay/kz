package kz.epam.webproject.command.service;

import kz.epam.webproject.action.UserAction;
import kz.epam.webproject.dao.DaoException;
import kz.epam.webproject.dao.impl.UserDaoImpl;
import kz.epam.webproject.validator.UserValidator;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;

import java.util.Set;

public class UserService {
    private static Logger logger = Logger.getLogger(UserService.class);
    private static UserDaoImpl userDao = new UserDaoImpl();
    /**
     * This method is used to go to JSP page 'shop' from JSP page 'login'.
     * It checks whether user registered in web-server.
     *
     * @param email    String email of user
     * @param password String password of user
     *                 First email and password is checked for validity, in case of success, both inputs
     *                 will be encrypted and send to UserDaoImpls signIn method
     * @return if inputs are invalid, returns false,
     * if inputs are valid, and no such user found in database, returns false,
     * if inputs are valid, and appropriate user found in databse, returns true;
     */
    public static boolean checkLogin(String email, String password) {
        if (UserValidator.validateUser(email, password)) {
            try {
                return userDao.singIn(UserAction.encrypInput(email), UserAction.encrypInput(password));
            } catch (DaoException e) {
                logger.log(Level.ERROR,e.getMessage());
            }
        }
        return false;
    }

    /**
     * This method is used to register new user in server (database). First validity of inputs are checked,
     * then if all inputs are valid, parameter age changed to one of values: 'T' or 'F'. After UserDaoImple method
     * addUser is called with all parameters encrypted before hand.
     *
     * @param name     String name of user
     * @param email    String email of user
     * @param password String password of user
     * @param age      String age of user, can be 'under_18' or "over_18'
     * @param jobRole  String job role of user, can be null, or empty
     * @return if all inputs are valid and no exception from UserDaoImpl send, returns true, else false;
     */
    public static boolean addNewUser(String name, String email, String password, String age, String jobRole) {
        if (UserValidator.validateUser(name, email, password, age, jobRole)) {
            age = UserAction.changeAge(age);
            return userDao.addUser(UserAction.encrypInput(name), UserAction.encrypInput(email), UserAction.encrypInput(password), UserAction.encrypInput(age), UserAction.encrypInput(jobRole));
        } else {
            return false;
        }
    }

    /**
     * This method is used to add courses bought by user with given email in JSP page 'cart';
     * Since all information in database stored in form of ciphertext, before sending to UserDaoImpl class,
     * email of user is encrypted
     *
     * @param email String email of user
     * @param set   Set of Strings which contains names of courses to be added to user with given email
     * @return returns result of UserDaoImpl addCourse method, where email send encrypted and set without any changes
     */
    public static String addCourseToUser(String email, Set<String> set) {
        return userDao.addCourse(UserAction.encrypInput(email), set);
    }

    /**
     * This method is used to show number of people already taken this course.
     * It counts number of people from database and then returns count.
     * Since course name is name of column in table contentcourse, it do not need to be encrypted
     *
     * @param courseName String name of course
     * @return if no one taken given course, returns zero,
     * else number of people taken this course
     */
    public static int peopleTaken(String courseName) {
        try {
            return userDao.getPeopleTaken(courseName);
        } catch (DaoException e) {
            return -1;
        }
    }

    /**
     * Private constructor to make sure that no one creates instance of this class
     */
    private UserService() {
        throw new IllegalStateException("Utility Class");
    }
}
