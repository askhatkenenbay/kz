package kz.epam.webproject.command;

import kz.epam.webproject.command.impl.*;

public enum CommandType {
    LOGIN(new LoginCommand()), LOGOUT(new LogoutCommand()), REGISTER(new RegisterCommand()), SHOP(new ShopCommand()),
    REGISTER_USER(new RegisterUserCommand()), COURSE_INFORMATION(new CourseInformationCommand()),
    GO_TO_CART(new GoToCartCommand()), BUY(new BuyCommand());

    /**
     * @param command Command which will be executed for this enum CommandType
     */
    CommandType(Command command) {
        this.command = command;
    }

    private Command command;

    /**
     * @return returns command of this CommandType enum
     */
    public Command getCommand() {
        return command;
    }
}
