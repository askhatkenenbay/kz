package kz.epam.webproject.command.impl;

import kz.epam.webproject.command.Command;


import javax.servlet.http.HttpServletRequest;

import static kz.epam.webproject.command.impl.PageAdress.PAGE_REGISTER;

public class RegisterCommand implements Command {
    /**
     * This method is used to move user to registration page
     *
     * @param request request from JSP
     * @return page to register new users 'register'
     */
    @Override
    public String execute(HttpServletRequest request) {
        return PAGE_REGISTER;
    }
}
