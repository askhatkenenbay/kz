import kz.epam.webproject.validator.UserValidator;
import org.testng.annotations.Test;

import static org.testng.Assert.*;

public class UserValidatorTest {
    private static final boolean FALSE = false;
    private static final boolean TRUE = true;
    @Test
    public void validateUsershortEmail(){
        String shortEmail = "short";
        String password = "password";
        assertEquals(FALSE,UserValidator.validateUser(shortEmail,password) );
    }
    @Test
    public void validateUserlongEmail(){
        String longEmail = "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa";
        String password = "password";
        assertEquals(FALSE,UserValidator.validateUser(longEmail,password) );
    }
    @Test
    public void validateUserNullEmail(){
        String nullEmail = null;
        String password = "password";
        assertEquals(FALSE,UserValidator.validateUser(nullEmail,password) );
    }
    @Test
    public void validateUserNullPassword(){
        String email = "random@gmail.com";
        String password = null;
        assertEquals(FALSE,UserValidator.validateUser(email,password) );
    }
    @Test
    public void validateUserShortPassword(){
        String email = "random@gmail.com";
        String shortPassword = "short";
        assertEquals(FALSE,UserValidator.validateUser(email,shortPassword) );
    }
    @Test
    public void validateUserLongPassword(){
        String email = "random@gmail.com";
        String longPassword = "aaaaaaaaaaaaaaaaaaaaaaaaaa";
        assertEquals(FALSE,UserValidator.validateUser(email,longPassword) );
    }
    @Test
    public void validateUserNullName(){
        String name = null;
        String email = "random@gmail.com";
        String password = "password";
        String age = "under_18";
        String job_role = null;
        assertEquals(FALSE, UserValidator.validateUser(name,email,password,age,job_role));
    }
    @Test
    public void validateUserShortName(){
        String shortName = "a";
        String email = "random@gmail.com";
        String password = "password";
        String age = "under_18";
        String job_role = null;
        assertEquals(FALSE, UserValidator.validateUser(shortName,email,password,age,job_role));
    }
    @Test
    public void validateUserLonfName(){
        String longName = "aaaaaaaaaaaaaaaaaaaaa";
        String email = "random@gmail.com";
        String password = "password";
        String age = "under_18";
        String job_role = null;
        assertEquals(FALSE, UserValidator.validateUser(longName,email,password,age,job_role));
    }

    @Test
    public void validateUserInvalidAge(){
        String name = "name";
        String email = "random@gmail.com";
        String password = "password";
        String age = "invalid";
        String job_role = null;
        assertEquals(FALSE, UserValidator.validateUser(name,email,password,age,job_role));
    }
    @Test
    public void validateUserUnderdAge(){
        String name = "name";
        String email = "random@gmail.com";
        String password = "password";
        String age = "under_18";
        String job_role = null;
        assertEquals(TRUE, UserValidator.validateUser(name,email,password,age,job_role));
    }
    @Test
    public void validateUserOverAge(){
        String name = "name";
        String email = "random@gmail.com";
        String password = "password";
        String age = "over_18";
        String job_role = null;
        assertEquals(TRUE, UserValidator.validateUser(name,email,password,age,job_role));
    }
}
