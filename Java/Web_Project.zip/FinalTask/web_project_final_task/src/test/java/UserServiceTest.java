
import kz.epam.webproject.command.service.UserService;
import org.testng.annotations.Test;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;


public class UserServiceTest {
    @Test
    public void testCheckLogin1() {
        String login = null;
        String password = null;
        boolean result = false;
        assertEquals(result,UserService.checkLogin(login, password));
    }

    @Test
    public void testCheckLogin2() {
        String login = "somelogin";
        String password = null;
        boolean result = false;
        assertEquals(result,UserService.checkLogin(login, password));
    }

    @Test
    public void testCheckLogin3() {
        String login = null;
        String password = "somepassword";
        boolean result = false;
        assertEquals(result,UserService.checkLogin(login, password));
    }

    @Test
    public void testCheckLogin4() {
        String login = "noSuchUser";
        String password = "noSuchPassword";
        boolean result = false;
        assertEquals(result,UserService.checkLogin(login, password));
    }

    @Test
    public void testAddNewUser() {
        String name = "someName";
        String email = "";  //invalid email
        String password = "somePassword";
        String age = "under_18";
        String job_role = null;
        boolean result = false;
        assertEquals(result,UserService.addNewUser(name,email,password,age,job_role));
    }

    @Test
    public void testPeopleTakenPython(){
        String course = "Python";
        assertTrue(UserService.peopleTaken(course)>=0);
    }

    @Test
    public void testPeopleTakenInvalidCourse(){
        String course = "noSuchCourse";
        int result = -1;
        assertEquals(result,UserService.peopleTaken(course));
    }

    @Test(expectedExceptions = NullPointerException.class)
    public void testPeopleTakenNullInput(){
        String course = null;
        UserService.peopleTaken(course);
    }
}
