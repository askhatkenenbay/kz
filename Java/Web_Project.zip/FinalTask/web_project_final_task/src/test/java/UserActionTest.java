import kz.epam.webproject.action.UserAction;
import org.testng.annotations.Test;

import static org.testng.Assert.assertEquals;

public class UserActionTest {

    @Test
    public void testChangeAgeWithUnder() {
        String age = "under_18";
        String result = "F";
        assertEquals(result, UserAction.changeAge(age));
    }

    @Test
    public void testChangeAgeWithOver() {
        String age = "over_18";
        String result = "T";
        assertEquals(result, UserAction.changeAge(age));
    }

    @Test
    public void testChangeAgeWith() {
        String age = "noOptions";
        assertEquals(age, UserAction.changeAge(age));
    }

    @Test
    public void testEncryptionInvalidInput() {
        String plaintext = null;
        String result = "";
        assertEquals(result, UserAction.encrypInput(plaintext));
    }
}
