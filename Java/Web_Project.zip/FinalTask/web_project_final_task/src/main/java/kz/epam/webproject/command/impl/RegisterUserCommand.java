package kz.epam.webproject.command.impl;

import kz.epam.webproject.command.Command;
import kz.epam.webproject.command.service.UserService;

import javax.servlet.http.HttpServletRequest;

import static kz.epam.webproject.command.impl.PageAdress.PAGE_LOGIN;

public class RegisterUserCommand implements Command {
    private static final String PARAM_NAME = "user_name";
    private static final String PARAM_EMAIL = "user_email";
    private static final String PARAM_PASSWORD = "user_password";
    private static final String PARAM_AGE = "user_age";
    private static final String PARAM_JOB = "user_job";
    private static final String REGISTRATION_SUCCEEDED = "Registered";
    private static final String REGISTRATION_FAILED = "Registration failed";

    /**
     * This method is used to register new user in server.
     * It collects all needed information from request and sends them to
     * UserService class's addNewUser() method. Depending on results
     * of this method, respective message will be send to user in login page;
     *
     * @param request request from JSP page
     * @return login page with message about registration
     */
    @Override
    public String execute(HttpServletRequest request) {
        String name = request.getParameter(PARAM_NAME);
        String email = request.getParameter(PARAM_EMAIL);
        String password = request.getParameter(PARAM_PASSWORD);
        String age = request.getParameter(PARAM_AGE);
        String jobRole = request.getParameter(PARAM_JOB);
        if (UserService.addNewUser(name, email, password, age, jobRole)) {
            request.setAttribute("user", REGISTRATION_SUCCEEDED);
        } else {
            request.setAttribute("errorLoginPassMessage", REGISTRATION_FAILED);
        }
        return PAGE_LOGIN;
    }
}
