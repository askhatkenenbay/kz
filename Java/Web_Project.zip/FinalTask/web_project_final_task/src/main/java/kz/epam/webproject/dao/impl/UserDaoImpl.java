package kz.epam.webproject.dao.impl;

import kz.epam.webproject.connection.ConnectionPool;
import kz.epam.webproject.dao.UserDao;
import kz.epam.webproject.dao.DaoException;
import kz.epam.webproject.entity.Customer;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

public class UserDaoImpl implements UserDao {
    private static Logger logger = Logger.getLogger(UserDaoImpl.class);

    private static final String SELECT_EXACT_EMAIL = "SELECT email FROM infcustomer WHERE email=?";
    private static final String INSERT_USER_TO_INFCUSTOMER = "INSERT INTO infcustomer(customer_name, email, customer_password, age, job_role) VALUES(?,?,?,?,?)";
    private static final String SELECT_EXACT_EMAIL_PASSWORD_FROM_INFCUSTOMER = "SELECT email, customer_password FROM infcustomer WHERE email=? and customer_password=?";
    private static final String INSERT_USER_TO_CONTENTCOURSE = "INSERT INTO contentcourse(email,Python,Java,PHP,Android,cPlus,Kotlin,cSharp,Javascript) VALUES(?,?,?,?,?,?,?,?,?)";
    private static final String GET_NUMBER_OF_COLUMNS_FROM_CONTENTCOURSE = "SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE  table_name = 'contentcourse'";

    private static final String STRING_T = "T";
    private static final String STRING_F = "F";
    private static final String TRANSACTION_FAILED_MESSAGE = "Transaction failed! Sorry for inconvenient";
    private static final String TRANSACTION_SUCCEEDED_MESSAGE = "Transaction completed Successfully!";
    private static final String TRANSACTION_INVALID_ORDER_MESSAGE = "You already have one or more courses chosen by you, transaction failed";

    /**
     * This method is used to add new user to database, especially to two table.
     * First method checkUser with parameter email send, is called, to make sure that
     * no one else registered with same email, if its not the case method proceed further, else returns false;
     * New User will be added to two database tables, infcustomer and contentcourse respectively.
     * Two methods called insertToInfcustomer and insertToContentcourse, AND operation of which will be result of the method
     *
     * @param name     encrypted user name
     * @param email    encrypted email
     * @param password encrypted password
     * @param age      encrypted age
     * @param job      encrypted job role
     * @return returns true if user successfully added to database, else returns false
     */
    @Override
    public boolean addUser(String name, String email, String password, String age, String job) {
        Connection connection = null;
        boolean result = true;
        try {
            connection = ConnectionPool.INSTANCE.getConnection();
            if (!checkUser(email, connection)) {
                result = false;
            } else {
                result = (insertToInfcustomer(name, email, password, age, job, connection) && insertToContentcourse(email, connection));
            }
        } catch (Exception e) {
            logger.log(Level.ERROR,e.getMessage());
        } finally {
            close(connection);
        }
        return result;
    }

    /**
     * This method selects email column of infcustomer table where email is equal to given param 'email';
     * if nothing was found, returns true, it at least one coincidences,returns false;
     *
     * @param email      encrypted email of user
     * @param connection connection from addUser() method
     * @return if no user was found, returns true, otherwise false;
     */
    private boolean checkUser(String email, Connection connection) {
        PreparedStatement preparedStatement = null;
        ResultSet resultSet;
        boolean result = true;
        try {
            preparedStatement = connection.prepareStatement(SELECT_EXACT_EMAIL);
            preparedStatement.setString(1, email);
            resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                result = false;
            }
        } catch (SQLException e) {
            logger.log(Level.ERROR,e.getMessage());
        } finally {
            close(preparedStatement);
        }
        return result;
    }

    /**
     * This method is used to add new user to infcustomer table.
     * It uses preparedStatement for security against sql injection.
     * if any exception, error happen , returns false;
     *
     * @param name       encrypted name
     * @param email      encrypted email
     * @param password   encrypted password
     * @param age        encrypted age
     * @param job        encrypted job role
     * @param connection connection from addUser() method
     * @return if all parameters except connection was added to table infcustomer returns true, else false;
     */
    private boolean insertToInfcustomer(String name, String email, String password, String age, String job, Connection connection) {
        PreparedStatement preparedStatement = null;
        boolean result = false;
        try {
            preparedStatement = connection.prepareStatement(INSERT_USER_TO_INFCUSTOMER);
            preparedStatement.setString(1, name);
            preparedStatement.setString(2, email);
            preparedStatement.setString(3, password);
            preparedStatement.setString(4, age);
            preparedStatement.setString(5, job);
            int i = preparedStatement.executeUpdate();
            if (i > 0) {
                result = true;
            }
        } catch (SQLException e) {
            logger.log(Level.ERROR,e.getMessage());
        } finally {
            close(preparedStatement);
        }
        return result;
    }

    /**
     * This method is used to add new customer to contentcourse table;
     * It uses preparedStatement for security against sql injection.
     *
     * @param email      encrypted email
     * @param connection connection from addUser() method
     * @return returns true if one exception, error was caught, else false;
     */
    private boolean insertToContentcourse(String email, Connection connection) {
        PreparedStatement preparedStatement = null;
        PreparedStatement columnStatement;
        ResultSet columnResultSet;
        boolean result = false;
        try {
            preparedStatement = connection.prepareStatement(INSERT_USER_TO_CONTENTCOURSE);
            columnStatement = connection.prepareStatement(GET_NUMBER_OF_COLUMNS_FROM_CONTENTCOURSE);
            columnResultSet = columnStatement.executeQuery();
            columnResultSet.next();
            int numberOfColumn = columnResultSet.getInt(1);
            preparedStatement.setString(1, email);
            for (int i = 2; i <= numberOfColumn; i++) {
                preparedStatement.setString(i, STRING_F);
            }
            int i = preparedStatement.executeUpdate();
            if (i > 0) {
                result = true;
            }
        } catch (SQLException e) {
            logger.log(Level.ERROR,e.getMessage());
        } finally {
            close(preparedStatement);
        }
        return result;
    }

    /**
     * This method is user to log in already registered user.
     * It uses prepared statement to find user with exact same email and password from table infcustomer.
     * Since email is primary key of table , in case of at least one coincidence returns true, else false;
     *
     * @param login    encrypted email of user
     * @param password encrypted password
     * @return true, if user with same email,password was found, otherwise returns false
     * @throws DaoException in case of exception, error throws custom exception
     */
    @Override
    public boolean singIn(String login, String password) throws DaoException {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        boolean result;
        try {
            connection = ConnectionPool.INSTANCE.getConnection();
            preparedStatement = connection.prepareStatement(SELECT_EXACT_EMAIL_PASSWORD_FROM_INFCUSTOMER);
            preparedStatement.setString(1, login);
            preparedStatement.setString(2, password);
            resultSet = preparedStatement.executeQuery();
            result = resultSet.next();
        } catch (SQLException e) {
            logger.log(Level.ERROR,e.getMessage());
            throw new DaoException();
        } finally {
            close(preparedStatement);
            close(connection);
            try {
                if (resultSet != null) {
                    resultSet.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return result;
    }

    /**
     * This method is used to count number of people taken given course;
     *
     * @param courseName name of course
     * @return number of people taken given course
     * @throws DaoException in case of exception, error throws custom exception
     */
    @Override
    public int getPeopleTaken(String courseName) throws DaoException {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        int result = 0;
        try {
            connection = ConnectionPool.INSTANCE.getConnection();
            String sqlCall = "SELECT " + courseName + " FROM contentcourse";
            preparedStatement = connection.prepareStatement(sqlCall);
            ResultSet resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                if (STRING_T.equals(resultSet.getString(courseName))) {
                    result++;
                }
            }
        } catch (SQLException e) {
            logger.log(Level.ERROR,e.getMessage());
            throw new DaoException();
        } finally {
            close(preparedStatement);
            close(connection);
        }
        return result;
    }

    /**
     * This method is used to make transaction, save courses user bought from cart.
     *
     * @param login encrypted email of user
     * @param set   Set of strings containing names of courses to be added to user
     * @return message about transaction. Can be three types. In case of success, in case of failure
     * and in case of user already having bought one or more courses in param 'set'
     */
    @Override
    public String addCourse(String login, Set<String> set) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        try {
            connection = ConnectionPool.INSTANCE.getConnection();
            if (!checkOrder(login, set, connection)) {
                return TRANSACTION_INVALID_ORDER_MESSAGE;
            }
            for (String courseToAdd : set) {
                String update = "Update contentcourse SET " + courseToAdd + " =? where email=?";
                preparedStatement = connection.prepareStatement(update);
                preparedStatement.setString(1, STRING_T);
                preparedStatement.setString(2, login);
                preparedStatement.executeUpdate();
            }
            return TRANSACTION_SUCCEEDED_MESSAGE;
        } catch (SQLException e) {
            logger.log(Level.ERROR,e.getMessage());
            return TRANSACTION_FAILED_MESSAGE;
        } finally {
            close(connection);
            close(preparedStatement);
        }
    }

    /**
     * This method checks whether user aleady have one or more courses already bought
     *
     * @param login      encrypted email of user
     * @param set        Set of String course names, which used added in cart
     * @param connection connection from addCourse() method
     * @return true if user do not have bought any of courses in param 'set', else false
     */
    private boolean checkOrder(String login, Set<String> set, Connection connection) {
        PreparedStatement preparedStatement = null;
        boolean result = true;
        ResultSet resultSet = null;
        try {
            String sqlCall = "SELECT * FROM contentcourse where email = ?";
            preparedStatement = connection.prepareStatement(sqlCall);
            preparedStatement.setString(1, login);
            resultSet = preparedStatement.executeQuery();
            resultSet.next();
            for (String course : set) {
                if (STRING_T.equals(resultSet.getString(course))) {
                    result = false;
                    break;
                }
            }
        } catch (SQLException e) {
            logger.log(Level.ERROR,e.getMessage());
        } finally {
            close(preparedStatement);
        }
        return result;
    }

    @Override
    public int getTotalPrice(String login) throws DaoException {
        throw new DaoException(new UnsupportedOperationException());
    }

    @Override
    public List<Customer> findAll() throws DaoException {
        throw new DaoException(new UnsupportedOperationException());
    }

    @Override
    public Customer findById(String id) throws DaoException {
        throw new DaoException(new UnsupportedOperationException());
    }

    @Override
    public boolean delete(String id) throws DaoException {
        throw new DaoException(new UnsupportedOperationException());
    }

    @Override
    public boolean delete(Customer entity) throws DaoException {
        throw new DaoException(new UnsupportedOperationException());
    }

    @Override
    public boolean create(Customer entity) throws DaoException {
        throw new DaoException(new UnsupportedOperationException());
    }

    @Override
    public Customer update(Customer entity) throws DaoException {
        throw new DaoException(new UnsupportedOperationException());
    }
}
