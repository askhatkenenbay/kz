import kz.epam.webproject.command.CommandFactory;
import kz.epam.webproject.command.impl.*;
import org.testng.annotations.Test;

import static org.testng.Assert.assertTrue;

public class CommandFactoryTest {

    @Test
    public void defineCommandNullInput(){
        String input = null;
        assertTrue(CommandFactory.defineCommand(input) instanceof EmptyCommand);
    }

    @Test
    public void defineCommandBlankInput(){
        String input = "  ";
        assertTrue(CommandFactory.defineCommand(input) instanceof EmptyCommand);
    }

    @Test
    public void defineCommandLoginInput(){
        String input = "login";
        assertTrue(CommandFactory.defineCommand(input) instanceof LoginCommand);
    }

    @Test
    public void defineCommandLogoutInput(){
        String input = "logout";
        assertTrue(CommandFactory.defineCommand(input) instanceof LogoutCommand);
    }

    @Test
    public void defineCommandRegisterInput(){
        String input = "REGISTER";
        assertTrue(CommandFactory.defineCommand(input) instanceof RegisterCommand);
    }

    @Test
    public void defineCommandShopInput(){
        String input = "SHOP";
        assertTrue(CommandFactory.defineCommand(input) instanceof ShopCommand);
    }

    @Test
    public void defineCommandRegisterUserInput(){
        String input = "REGISTER_USER";
        assertTrue(CommandFactory.defineCommand(input) instanceof RegisterUserCommand);
    }

    @Test
    public void defineCommandCourseInformationInput(){
        String input = "COURSE_INFORMATION";
        assertTrue(CommandFactory.defineCommand(input) instanceof CourseInformationCommand);
    }

    @Test
    public void defineCommandGoToCartInput(){
        String input = "GO_TO_CART";
        assertTrue(CommandFactory.defineCommand(input) instanceof GoToCartCommand);
    }

    @Test
    public void defineCommandBuyInput(){
        String input = "BUY";
        assertTrue(CommandFactory.defineCommand(input) instanceof BuyCommand);
    }
}
