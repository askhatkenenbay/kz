package kz.epam.webproject.command.impl;

class PageAdress {
    static final String PARAM_LOGIN = "login";
    static final String PARAM_PASSWORD = "password";
    //pages
    static final String PAGE_LOGIN = "/jsp/login.jsp";
    static final String PAGE_SHOP = "/jsp/shop.jsp";
    static final String PAGE_REGISTER = "/jsp/register.jsp";
    static final String PAGE_CART = "/jsp/cart.jsp";
    static final String PAGE_INDEX = "/index.jsp";
    static final String PAGE_TRANSACTION = "/jsp/transaction.jsp";

    /**
     * Private constructor to make sure that no one creates instance of this class.
     * Stores information package-private
     */
    private PageAdress(){
        throw new IllegalStateException("Utility Class");
    }
}
