package kz.epam.webproject.command.impl;

import kz.epam.webproject.command.Command;

import javax.servlet.http.HttpServletRequest;

import static kz.epam.webproject.command.impl.PageAdress.PAGE_INDEX;

public class EmptyCommand implements Command {
    /**
     * This method is used whenever there are problems with execution of methods, or
     * if user tries to go to page of website via direct link
     *
     * @param request request from JSP page
     * @return start page (index page)
     */
    @Override
    public String execute(HttpServletRequest request) {
        return PAGE_INDEX;
    }
}
