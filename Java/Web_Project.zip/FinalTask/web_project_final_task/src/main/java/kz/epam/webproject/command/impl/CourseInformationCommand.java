package kz.epam.webproject.command.impl;

import kz.epam.webproject.command.Command;
import kz.epam.webproject.command.service.UserService;

import javax.servlet.http.HttpServletRequest;

public class CourseInformationCommand implements Command {
    //possible courses
    private static final String PYTHON = "Python";
    private static final String JAVA = "Java";
    private static final String PHP = "PHP";
    private static final String ANDROID = "Android";
    private static final String C_PLUS = "cPlus";
    private static final String KOTLIN = "Kotlin";
    private static final String C_SHARP = "cSharp";
    private static final String JAVASCRIPT = "Javascript";
    //links
    private static final String PYTHON_PAGE = "/jsp/course/python.jsp";
    private static final String JAVA_PAGE = "/jsp/course/java.jsp";
    private static final String PHP_PAGE = "/jsp/course/php.jsp";
    private static final String ANDROID_PAGE = "/jsp/course/android.jsp";
    private static final String C_PLUS_PAGE = "/jsp/course/cplus.jsp";
    private static final String KOTLIN_PAGE = "/jsp/course/kotlin.jsp";
    private static final String C_SHARP_PAGE = "/jsp/course/csharp.jsp";
    private static final String JAVASCRIPT_PAGE = "/jsp/course/javascript.jsp";

    /**
     * This method is called when user press button 'See More'.Method first gets number of
     * people taken course to which page user going to move, saves it in request's attribute 'peopleTaken',
     * and at the end moves user to information page of given course
     *
     * @param request request from JSP page
     * @return String page
     */
    @Override
    public String execute(HttpServletRequest request) {
        String course = request.getParameter("course");
        int peopleTaken = UserService.peopleTaken(course);
        request.setAttribute("peopleTaken", peopleTaken);
        if (course.equals(PYTHON)) {
            return PYTHON_PAGE;
        }
        if (course.equals(JAVA)) {
            return JAVA_PAGE;
        }
        if (course.equals(ANDROID)) {
            return ANDROID_PAGE;
        }
        if (course.equals(C_PLUS)) {
            return C_PLUS_PAGE;
        }
        if (course.equals(C_SHARP)) {
            return C_SHARP_PAGE;
        }
        if (course.equals(JAVASCRIPT)) {
            return JAVASCRIPT_PAGE;
        }
        if (course.equals(KOTLIN)) {
            return KOTLIN_PAGE;
        }
        if (course.equals(PHP)) {
            return PHP_PAGE;
        }
        //never executed
        return null;
    }
}
