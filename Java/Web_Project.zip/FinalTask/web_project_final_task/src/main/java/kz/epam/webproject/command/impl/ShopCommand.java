package kz.epam.webproject.command.impl;

import kz.epam.webproject.command.Command;
import org.apache.log4j.Logger;

import javax.servlet.http.HttpServletRequest;

import static kz.epam.webproject.command.impl.PageAdress.PAGE_SHOP;

public class ShopCommand implements Command {
    private static Logger logger = Logger.getLogger(ShopCommand.class);

    /**
     * This method is called to move user to 'shop' page
     *
     * @param request request from JSP
     * @return page of 'shop'
     */
    @Override
    public String execute(HttpServletRequest request) {
        logger.info("user went to shop");
        return PAGE_SHOP;
    }
}
