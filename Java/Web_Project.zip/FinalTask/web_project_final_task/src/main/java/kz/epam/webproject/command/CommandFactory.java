package kz.epam.webproject.command;

import kz.epam.webproject.command.impl.EmptyCommand;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
public class CommandFactory {
    private static Logger logger = Logger.getLogger(CommandFactory.class);
    /**
     * This method is used to find which command to be executed
     *
     * @param action hidden input value from JSP
     * @return if input is null or blank, EmptyCommand() will be returned,
     * else if input is not blank, but cannot find appropriate command, EmptyCommand() will be returned,
     * else if input is not blank and appropriate command was found, this command will be returned
     */
    public static Command defineCommand(String action) {
        Command current;
        if (action == null || action.isBlank()) {
            return new EmptyCommand();
        }
        try {
            CommandType currentType = CommandType.valueOf(action.toUpperCase());
            current = currentType.getCommand();
        } catch (IllegalArgumentException e) {
            logger.log(Level.ERROR,"np such command");
            current = new EmptyCommand();
        }
        return current;
    }

    /**
     * Private constructor to make sure that no one creates instance of this class
     */
    private CommandFactory() {
        throw new IllegalStateException("Utility Class");
    }
}
