package kz.epam.webproject.command.impl;

import kz.epam.webproject.command.Command;
import kz.epam.webproject.command.service.UserService;

import javax.servlet.http.HttpServletRequest;

import static kz.epam.webproject.command.impl.PageAdress.*;

public class LoginCommand implements Command {
    private static final String FAILED_LOG = "incorrect login or password";

    /**
     * This method is used to check email and password of user, before moving user to shop page.
     * If user already registered, its login (email) is saved in session, so in case if user will
     * buy some courses in cart, to know to which user add courses.
     *
     * @param request request from JSP page
     * @return if user registered, returns page of 'shop',
     * else returns page of 'login' (restarts current page) with message for user
     */
    @Override
    public String execute(HttpServletRequest request) {
        String login = request.getParameter(PARAM_LOGIN);
        String pass = request.getParameter(PARAM_PASSWORD);
        if (UserService.checkLogin(login, pass)) {
            request.setAttribute("user", login);
            request.getSession().setAttribute("login", login);
            return PAGE_SHOP;
        } else {
            request.setAttribute("errorLoginPassMessage", FAILED_LOG);
            return PAGE_LOGIN;
        }
    }
}
