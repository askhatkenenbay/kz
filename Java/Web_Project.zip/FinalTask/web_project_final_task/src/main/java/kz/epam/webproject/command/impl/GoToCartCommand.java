package kz.epam.webproject.command.impl;

import kz.epam.webproject.command.Command;

import javax.servlet.http.HttpServletRequest;

import static kz.epam.webproject.command.impl.PageAdress.PAGE_CART;


public class GoToCartCommand implements Command {
    /**
     * This methods moves user from 'shop' page to 'cart' page
     *
     * @param request request from JSP page
     * @return page of 'cart'
     */
    @Override
    public String execute(HttpServletRequest request) {
        return PAGE_CART;
    }
}
