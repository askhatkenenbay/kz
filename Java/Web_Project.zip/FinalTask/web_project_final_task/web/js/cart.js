function changeCourse(temp, price, inputId){
    var button = document.getElementById(temp);
    var float_price = parseFloat(price);
    if(button.innerText == "Add"){
        document.getElementById(temp).innerText = "Remove";
        document.getElementById(temp).parentElement.style.backgroundColor = "#ff0000";
        //document.getElementById(temp).parentNode.parentNode.firstChild.value = "T";
        document.getElementById(inputId).value = "T";
    }else if (button.innerText == "Remove"){
        document.getElementById(temp).innerText = "Add";
        document.getElementById(temp).parentElement.style.backgroundColor = "#00ff00";
        //document.getElementById(temp).parentNode.parentNode.firstChild.value = "F";
        document.getElementById(inputId).value = "F";
        float_price = -float_price;
    }
    updatePrice(float_price);
}
function updatePrice(price){
    var total_price_label = document.getElementById("totalPrice");
    var total = parseFloat(total_price_label.innerText.replace("$", ""));
    total = total + price;
    total = Math.round(total * 100) / 100;
    document.getElementById("totalPrice").innerText = "$" + total;
}
function removeAll() {
    var products = document.getElementsByClassName("add-button");

    for(var i = 0; i < products.length; i++){
        var product_label = products[i].firstChild;
        if(product_label.innerText == "Remove"){
            product_label.click();
        }
    }
}

